# Happy-Bouncing-Ball
It’s a fun project to do to liven up your user experience
My first Project


# Key concept covered:

  Functions and if-else statements
  Random
  Event listeners
